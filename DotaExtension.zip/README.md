# LiquipediaExtension
Extension to tell me what games are currently happening
